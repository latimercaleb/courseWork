// Lab 4 question 1 programmed by Caleb Latimer

#include<iostream>
#include <iomanip>

using namespace std;

int main()
{
	double netBalance, payment, d1, d2, averageDailyBalance, interest, ipm; // ipm = interest rate per month 
	
	cout << "Feed me data ? " << endl; // Prompt user 
	cin >> netBalance >> payment >> d1 >> d2 >> ipm; // Gather data

	averageDailyBalance = (netBalance * d1 - payment *d2) / d1;
	interest = averageDailyBalance * ipm; // Computation

	cout << fixed << showpoint << setprecision(2); // Modifying the output
	cout << "The interest on your account is " << interest << endl; // End result 

	return 0;
}