// Build excercise programmed by Caleb Latimer
#include <iostream> // part a
using namespace std; // part b

int main()
{
	int num1, num2, num3, avg; // part c
	num1 = 125; // part d
		num2 = 28;
		num3 = -25;
	avg = (num1 + num2 + num3) / 3; // part e
	cout << "num1 is " << num1 << endl; 
	cout << "num2 is " << num2 << endl;
	cout << "num3 is " << num3 << endl;
	cout << "The average of num is " << avg << endl; // part f
	

	return 0;
}